package com.example.ali_arslan_project2;

public class Item2 {
    public String id;
    public String name;
    public String less;
    public String userId;
    public String inventoryId;
    public Item2(String id, String name, String less,String userId,String inventoryId  ) {
        this.id = id;
        this.name = name;
        this.less = less;
        this.userId = userId;
        this.inventoryId = inventoryId;
    }


}
